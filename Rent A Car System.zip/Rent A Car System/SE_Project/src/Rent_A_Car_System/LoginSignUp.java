package Rent_A_Car_System;
import java.util.Scanner;
public class LoginSignUp {
    Scanner sc=new Scanner(System.in);
    Scanner scString =new Scanner(System.in);
         String SignUpName;
         String LoginName;
         String SignUpPassword="";
         String SignUpPassword1="";
         String LoginPassword;
         void SignUp()
         {
             System.out.println(" ");
             System.out.println(" For SignUp enter  User Name and Password ");
             System.out.println(" *** Login Registration Form ***");
             System.out.print(" Enter_User_Name : ");
             SignUpName=scString.nextLine();
             System.out.print(" Enter_Password :  ");
             SignUpPassword=scString.nextLine();
             System.out.print(" Confirm_Password: ");
             SignUpPassword1=scString.nextLine();
             if(SignUpPassword.length()!=SignUpPassword1.length())
             {
                 do {
                     System.out.println(" You  Enter wrong password please enter right ");
                     System.out.print(" Enter_Password :  ");
                     SignUpPassword=scString.nextLine();
                     System.out.print(" Confirm_Password: ");
                     SignUpPassword1=scString.nextLine();
                 }while (SignUpPassword.length()!=SignUpPassword1.length());
             }

         }

         void login()
         {
             System.out.println(" ");
             System.out.println(" For Login enter Correct UserName and Password ");
             System.out.println(" ************ Login ************");
             System.out.print(" Enter User Name : ");
             LoginName=scString.nextLine();
             System.out.print(" Enter Password : ");
             LoginPassword=scString.nextLine();
         }

    public static void main(String[] args) {
        LoginSignUp o=new LoginSignUp();
     //  o.SignUp();

       //o.login();
    }
}
