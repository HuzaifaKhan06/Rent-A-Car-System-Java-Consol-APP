package Rent_A_Car_System;
import java.util.Scanner;
public class payments extends user{
    cars Cobj=new cars();
    Scanner sc=new Scanner(System.in);
    Scanner scString =new Scanner(System.in);
    int cardnum;
    int expyear;
    String coname;
    int payamount;
    void paymentDetail()
    {
        System.out.println(" ************* Add your payments details *************");
        System.out.print(" Enter Your Card Owner Name : ");
        coname=scString.nextLine();
        System.out.print(" Enter Your Card Number : ");
        cardnum=sc.nextInt();
        System.out.print(" Enter Your Card year OF Exp : ");
        expyear=sc.nextInt();
    }
    void pay_bill()
    {
        System.out.println(" Pay Your Amount : ");
        payamount=sc.nextInt();
        System.out.println(" Your Bill is Paid....!");
    }
}
