package Rent_A_Car_System;

import java.sql.Driver;
import java.util.Scanner;
public class cars extends LoginSignUp {
    Scanner sc=new Scanner(System.in);
    Scanner scString =new Scanner(System.in);
    int question;
    int Diver;
    int days;
    int driver_charges=3000;
    int CarChoose;
    int bill;
    void ques()
    {
        System.out.println(" Press 1 for Company suggestion for a Car.....!");
        System.out.println(" press 2 for your choice of car...........! ");
        System.out.print(" Select Your Choice : ");
        question=sc.nextInt();
        if(question==1)
        {
            System.out.println(" < Please Give us some information >");
            String place;
            String route;
            String Luxury_Classic;
            System.out.println(" Where you want to travel?");
            place=scString.nextLine();
            System.out.println(" What type of your Route is? Clean Road or Steap Road");
            route=scString.nextLine();
            System.out.println(" Which car you want Luxury or Classic?");
            Luxury_Classic=scString.nextLine();
            if(place=="Islamabad" && route=="clean"&& Luxury_Classic=="luxury")
            {
                System.out.println(" Suggested Cars are ");
                System.out.println(" < Honda Civic > \n < Xli > \n < Land Crusier > ");
                System.out.println(" You can choose any one of these \n These vehicles are best for your route");
            }
            else if (place=="Naran Kahagan" && route=="Steap"&& Luxury_Classic=="luxury")
            {
                System.out.println(" Suggested Vehicle are ");
                System.out.println(" < > \n < Toyota Revo  > \n < Land Crusier > ");
                System.out.println(" You can choose any one of these \n These vehicles are best for your route");
            }
            else if (place=="Naran Kahagan " && route=="Steap"&& Luxury_Classic=="classic")
            {
                System.out.println(" Suggested Vehicle are ");
                System.out.println(" < Toyota Revo > \n < 4*4 jEEP  > \n < Land Crusier > ");
                System.out.println(" You can choose any one of these \n These vehicles are best for your route");
            }
            else
            {
                System.out.println(" Suggested Vehicle are ");
                System.out.println(" < Toyota Fortuner > \n < Honda Civic > \n < Land Crusier > ");
                System.out.println(" < Toyota Revo > \n < 4*4 jEEP  > \n < Meharan > ");
                System.out.println(" < Cultus > \n < Audi > ");
                System.out.println(" You can choose any one of these \n These vehicles are best for your rute");
            }
        }
        else if(question==2)
        {
            System.out.println(" ***********************************");
            System.out.println(" ! Availabe Vehicles are !");
            System.out.println(" ***********************************");
            System.out.println(" ! Available Classic Vehicle !");
            System.out.println(" ***********************************");
            System.out.println(" < Car Name: Meharan > \n ModelNo: 2005 \n Rent: 3000 per Day without Petrol\n Car Type: Classic Low\n Colour: White \n Engine-Condition: Good\nFeature: FAN Avalable");
            System.out.println(" < Car Name: Crolla > \n ModelNo: 2005 \n Rent: 6000 per Day without Petrol\n Car Type: Classic \n Colour: Black \n Engine-Condition: Exellent\nFeature: AC/Heater Avalable");
            System.out.println(" < Car Name: Cultus > \n ModelNo: 2010 \n Rent: 3500 per Day without Petrol\n Car Type: Classic \n Colour: White \n Engine-Condition: Exellent\nFeature: AC/Heater Avalable");
            System.out.println(" < Car Name: Alto > \n ModelNo: 2012 \n Rent: 3400 per Day without Petrol\n Car Type: Classic \n Colour: White \n Engine-Condition: Exellent\nFeature: AC/Heater Avalable");
            System.out.println(" < Car Name: Atls > \n ModelNo: 2013 \n Rent: 3600 per Day without Petrol \n Car Type: Classic \n Colour: White \n Engine-Condition: Exellent\nFeature: AC/Heater Avalable");

            System.out.println(" ");
            System.out.println(" ***********************************");
            System.out.println(" ! Available Luxury Vehicle !");
            System.out.println(" ***********************************");
            System.out.println(" < Car Name: Honda Civic > \n ModelNo: 2020 \n Rent: 8000/ Day without Petrol\n Car Type: Luxury\n Colour: White \n Engine-Condition: Good\nFeature: AC/Heater Avalable");
            System.out.println(" < Car Name: Toyota Revo > \n ModelNo: 2017 \n Rent: 15000 per Day without Petrol\n Car Type: Luxury \n Colour: Black \n Engine-Condition: Exellent\nFeature: AC/Heater Avalable");
            System.out.println(" < Car Name: Audi > \n ModelNo: 2018 \n Rent: 7000 per Day without Petrol\n Car Type: Luxury \n Colour: Silver \n Engine-Condition: Exellent\nFeature: AC/Heater Avalable");
            System.out.println(" < Car Name: 4*4 jEEP > \n ModelNo: 2011 \n Rent: 13000 per Day without Petrol\n Car Type: Luxury \n Colour: Blue \n Engine-Condition: Exellent\nFeature: AC/Heater Avalable");
            System.out.println(" < Car Name: Land Crusier > \n ModelNo: 2013 \n Rent: 9500 per Day without Petrol \n Car Type: Luxury \n Colour: White \n Engine-Condition: Exellent\nFeature: AC/Heater Avalable");
            System.out.println(" < Car Name: XLI > \n ModelNo: 2014 \n Rent: 7500 per Day without Petrol \n Car Type: Luxury \n Colour: Grey \n Engine-Condition: Exellent\nFeature: AC/Heater Avalable");
            System.out.println(" < Car Name: Toyota Fortuner > \n ModelNo: 2017 \n Rent: 17000 per Day without Petrol \n Car Type: Luxury \n Colour: White \n Engine-Condition: Exellent\nFeature: AC/Heater Avalable");
        }
        else
        {
            System.out.println(" You have few selected options to choose your car.........!");
        }
        System.out.println(" < Press 1 for Meharan > ");
        System.out.println(" < Press 2 for Crolla > ");
        System.out.println(" < Press 3 for Cultus > ");
        System.out.println(" < Press 4 for Alto > ");
        System.out.println(" < Press 5 for Atls > ");
        System.out.println(" < Press 6 for Honda Civic > ");
        System.out.println(" < Press 7 for Toyota Revo > ");
        System.out.println(" < Press 8 for Audi > ");
        System.out.println(" < Press 9 for 4*4 jEEP > ");
        System.out.println(" < Press 10 for Land Crusier > ");
        System.out.println(" < Press 11 for XLI > ");
        System.out.println(" < Press 12 for Toyota Fortuner > ");
        System.out.print(" Choose Your Car : ");
        CarChoose=sc.nextInt();
        System.out.println(" For how many Days you need a vehicle? ");
        days=sc.nextInt();
    }
    void driver()
    {
        System.out.println(" Driver Charges are 3000 per Day ");
        System.out.println(" You want Driver with you?");
        System.out.println(" IF yes press 1 else Press 2");
        Diver=sc.nextInt();
        if(Diver==1) {
            if (CarChoose == 1 || Diver == 1) {
                bill = 3000;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Meharan");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2005");
                System.out.println(" Car Type : Classic Low");
                System.out.println(" Driver : No");
                System.out.println(" YOUR Updated Bill : " + ((bill * days) + (driver_charges * days)));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 2 || Diver == 1)) {
                bill = 6000;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Crolla");
                System.out.println(" Your Car colour is : Black");
                System.out.println(" Model_No : 2005");
                System.out.println(" Car Type : Classic ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated Bill : " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 3 || Diver == 1)) {
                bill = 3500;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Cultus");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2010");
                System.out.println(" Car Type : Classic ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated Bill : " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 4 || Diver == 1)) {
                bill = 3400;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Alto");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2010");
                System.out.println(" Car Type : Classic ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated Bill : " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 5 || Diver == 1)) {
                bill = 3600;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Atls");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2013");
                System.out.println(" Car Type : Classic ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated BillL : " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 6 || Diver == 1)) {
                bill = 8000;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Honda Civiv");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2020");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated Bill : " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 7 || Diver == 1)) {
                bill = 15000;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Toyota Revo");
                System.out.println(" Your Car colour is : Black");
                System.out.println(" Model_No : 2018");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated Bill : " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 8 || Diver == 1)) {
                bill = 7000;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Audi");
                System.out.println(" Your Car colour is : Black");
                System.out.println(" Model_No : 2018");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated Bill : " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 9 || Diver == 1)) {
                bill = 13000;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : 4*4 JEEP");
                System.out.println(" Your Car colour is : Blue");
                System.out.println(" Model_No : 2011");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated Bill: " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 10 || Diver == 1)) {
                bill = 9500;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Land Crusier");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2013");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated Bill : " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 11 || Diver == 1)) {
                bill = 7500;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : XLI");
                System.out.println(" Your Car colour is : Grey");
                System.out.println(" Model_No : 2014");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated Bill : " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 12 || Diver == 1)) {
                bill = 17000;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Fortuner");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2017");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" Driver : Yes");
                System.out.println(" YOUR Updated Bill : " + (bill * days) + (driver_charges * days));
                System.out.println(" ************************************************************ ");
            } else {
                System.out.println(" You Choose Wrong !");
            }
        }
        else
        {
            System.out.println(" Your bill remain same");
        }
    }
    void bill()
    {
        if (CarChoose == 1 ) {
            bill = 3000*days;
            System.out.println(" *************************** Bill *************************** ");
            System.out.println(" Your Car is : Meharan");
            System.out.println(" Your Car colour is : White");
            System.out.println(" Model_No : 2005");
            System.out.println(" Car Type : Classic Low");
            System.out.println(" YOUR BILL : " +bill);
            System.out.println(" ************************************************************ ");
        } else if (CarChoose == 2 )
        {
                bill = 6000*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Crolla");
                System.out.println(" Your Car colour is : Black");
                System.out.println(" Model_No : 2005");
                System.out.println(" Car Type : Classic ");
                System.out.println(" YOUR BILL : " + bill);
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 3 )) {
                bill = 3500*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Cultus");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2010");
                System.out.println(" Car Type : Classic ");
                System.out.println(" YOUR BILL : " + bill);
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 4 )) {
                bill = 3400*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Alto");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2012");
                System.out.println(" Car Type : Classic ");
                System.out.println(" YOUR BILL : " + bill);
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 5 )) {
                bill = 3600*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Atls");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2013");
                System.out.println(" Car Type : Classic ");
                System.out.println(" YOUR BILL : " + bill);
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 6 )) {
                bill = 8000*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Honda Civiv");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2020");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" YOUR BILL : " + bill);
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 7 )) {
                bill = 15000*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Toyota Revo");
                System.out.println(" Your Car colour is : Black");
                System.out.println(" Model_No : 2018");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" YOUR BILL : " + bill);
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 8 )) {
                bill = 7000*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Audi");
                System.out.println(" Your Car colour is : Black");
                System.out.println(" Model_No : 2018");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" YOUR BILL : " + bill);
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 9 )){
                bill = 13000*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : 4*4 JEEP");
                System.out.println(" Your Car colour is : Blue");
                System.out.println(" Model_No : 2011");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" YOUR BILL : " + bill);
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 10 )) {
                bill = 9500*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Land Crusier");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2013");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" YOUR BILL : " + bill);
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 11 )) {
                bill = 7500*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : XLI");
                System.out.println(" Your Car colour is : Grey");
                System.out.println(" Model_No : 2014");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" YOUR BILL : " + bill);
                System.out.println(" ************************************************************ ");
            } else if ((CarChoose == 12 )) {
                bill = 17000*days;
                System.out.println(" *************************** Bill *************************** ");
                System.out.println(" Your Car is : Fortuner");
                System.out.println(" Your Car colour is : White");
                System.out.println(" Model_No : 2017");
                System.out.println(" Car Type : Luxury ");
                System.out.println(" YOUR BILL : " + bill );
                System.out.println(" ************************************************************ ");
            }

        else
        {
            System.out.println(" you choose wrong");
        }
    }

    public static void main(String[] args) {
        cars ob = new cars();
        ob.ques();
        ob.bill();
        ob.driver();

    }


}
