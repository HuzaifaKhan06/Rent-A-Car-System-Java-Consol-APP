package Rent_A_Car_System;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        payments P_Obj=new payments();
        int z=-1;
       P_Obj.SignUp();
        do{
            P_Obj.login();
            if(P_Obj.LoginPassword.length()==P_Obj.SignUpPassword.length())
            {
                System.out.println(" Your  Login is Sucessfull >>>!");
                System.out.println("press 0 to move for next function : ");
                z=sc.nextInt();
            }
            else
            {
                System.out.println(" UserName and Passsword Does Not Match ");
                System.out.print("press 9 to login again : ");
                z=sc.nextInt();
            }
        }while(z!=0);
        System.out.println(" ");
        P_Obj.ques();
        P_Obj.bill();
        P_Obj.userInfo();
        P_Obj. paymentDetail();
        P_Obj.driver();
        P_Obj. pay_bill();
    }
}
