package Rent_A_Car_System;
import java.util.Scanner;
public class user extends cars{
    Scanner sc=new Scanner(System.in);
    Scanner scString =new Scanner(System.in);
    String Name;
    int Age;
    String IdCard;
    String Licnese;
    String BSDate;
    String BEDate;
    void userInfo()
    {
        System.out.println(" ************  Enter You Details ************ ");
        System.out.print(" Enter Your Name : ");
        Name=scString.nextLine();
        System.out.print(" Enter your age : ");
        Age=sc.nextInt();
        System.out.print(" Enter your NIC number : ");
        IdCard=scString.nextLine();
        System.out.print(" Enter your License number : ");
        Licnese=scString.nextLine();
        System.out.print(" Enter your Start date of Booking : ");
        BSDate=scString.nextLine();
        System.out.print(" Enter your End date of Booking : ");
        BEDate=scString.nextLine();
    }
}
